#ifndef __SYSTICK__
#define __SYSTICK__

void Configure_SysTick (void);
void SysTick_Wait1ms(unsigned long delay);
void SysTick_Wait1us(unsigned long delay);

#endif